(function(){

$(document).on("pageinit","#login", function(e){
    e.preventDefault();
    function onDeviceReady(){
      console.log(navigator.notification);



        $("pet00").on("tap", function(e){
          navigator.notification.alert(
            "You are the winner",
            alertDismissed,
            "Game Over",
            "Done"
          )}

        })



        function alertDismissed(){}


      }
      --> on device ready -->
    $(document).on("deviceready", onDeviceReady);
});
})();
